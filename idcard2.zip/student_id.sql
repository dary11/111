-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2018 at 07:24 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_id`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(50) NOT NULL,
  `profile` text NOT NULL,
  `name` text NOT NULL,
  `f_name` text NOT NULL,
  `m_name` text NOT NULL,
  `dob` date NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `class` text NOT NULL,
  `u_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `profile`, `name`, `f_name`, `m_name`, `dob`, `mobile`, `class`, `u_id`) VALUES
(1, '223.jpg', '', '', '', '0000-00-00', '', '', 0),
(2, '223.jpg', 'fgdfgdfg', 'gd', 'dfgdfg', '0000-00-00', '', '', 0),
(3, '223.jpg', 'fgdfgdfg', 'gd', 'dfgdfg', '2018-10-01', '', 'I', 0),
(4, '223.jpg', 'fgdfgdfg', 'gd', 'dfgdfg', '2018-10-01', '45465', 'I', 0),
(5, '123.jpg', 'd', 'asdasda', 'sdasd', '2018-10-08', '4654654', 'I', 1713),
(6, '1100.jpg', 'ravi kant saini', 'babu lal saini', 'kokila devi', '2000-02-01', '9887533754', 'VIII', 0),
(7, '1100.jpg', 'ravi kant saini', 'babu lal saini', 'kokila devi', '2000-02-01', '9887533754', 'VIII', 0),
(8, '1100.jpg', 'ravi kant saini', 'babu lal saini', 'kokila devi', '2000-02-01', '9887533754', 'VIII', 0),
(9, '1100.jpg', 'ravi kant saini', 'babu lal saini', 'kokila devi', '2000-02-01', '9887533754', 'VIII', 9891),
(10, '1100.jpg', 'ravi kant saini', 'babu lal saini', 'kokila devi', '2000-02-01', '9887533754', 'VIII', 7759),
(11, 'PHOTO125.jpg', 'Kamalesh Saini', 'Babu Lal Saini', 'Kokila Devi', '1998-02-20', '8502938283', 'VIII', 6297),
(12, 'log.jpg', 'Dilkhush Saini', 'Satyanarayan Saini', 'Manbhar devi', '2006-07-10', '9785364436', 'VIII', 7704),
(13, '5bc45219de2fc.jpg', 'Shubhan Saini', 'Hanuman Saini', 'Radha devi', '2000-12-28', '9057375633', 'VIII', 4821),
(14, '5bcb188873d2b.png', 'Roni kupar', 'Johan Sina', 'lorien', '1995-12-07', '985463254', 'VIII', 2524);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
